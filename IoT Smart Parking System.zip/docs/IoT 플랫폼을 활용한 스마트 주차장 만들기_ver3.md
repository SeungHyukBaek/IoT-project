# IoT 플랫폼을 활용한 스마트 주차장 만들기



## 1. 처음 구상

1. 자동차가 주차장 앞으로 오면, 초음파 센서로 차의 위치를 센싱한다. 자동차가 주차장 문 앞 10cm 이내로 접근했을 경우, 도어 버튼을 누르면 주차장 문이 열린다.
2.  주차장 문이 열리면서 LED가 켜진다. 자동차가 주차장으로 들어간 후, 도어 버튼을 누르면 주차장 문이 닫힌다.
3.  주차장 LED는 주차장 문이 열림/닫힘과 상관 없이 ON/OFF 할 수 있다.
4. 주차장에서 도어 버튼을 누르면 문이 열린다. 차가 나오고 다시 도어 버튼을 누르면 문이 닫힌다.
5. Stepper Motor 또는 로봇팔을 사용하여 주차장 천장을 개폐할 수 있다.
   * 참고 : LED 스트립 - 주차장 내부 불빛용으로 사용하고 외부 전원을 사용한다. (12V)
   * Servo Motor 또는 Stepper Motor - 주차장 문을 개폐하고 외부 전원을 사용한다. (5V)
   * App Inventor를 사용하여 주차장 문을 개폐하고 LED를 ON/OFF할 수 있다.



## 2. 결과 내용

**결과를 전체적으로 보면 아두이노에서는 각종 센서와 디바이스를 달았으며, 아두이노를 통해서 디바이스들이 작동하게 된다. 라즈베리파이는 웹을 만들어서 Wi-Fi로 스마트 주차장을 제어하기 위해 아두이노와 연결했다. 아두이노와 라즈베리 파이는 시리얼 통신으로 연결이 되어있다.  RF태그에 소유자의 ID 카드를 태그해야 주차장 문 개폐 동작을 할 수 있고, 조명과 환풍기 조작이 가능하다. 주차장 문은 아래와 같은 시나리오대로 동작을 할 수 있다. 조명과 환풍기는 RF 카드를 태그한 후에는 언제든지 키고 끌 수 있다. 환풍기는 3단계 속도 조절이 가능하다.**

1. 자동차가 주차장 앞으로 오면, 초음파 센서로 차의 위치를 센싱한다. 등록된 RFID 카드를 RFID 리더기에 태그해야만 주차장의 모든

   장치들을 조작할 수 있다.

2. 도어 스위치 또는 Bluetooth 어플의 도어 버튼 또는 웹의 도어 버튼을 누르면 LCD에 "Opening doors"라고 표시되며, 부저가 울리고, LED가 켜지고, 주차장 문이 열린다. 문이 열리면 LCD에 "Door opened"라고 표시되고 부저가 울리고, 팬이 회전한다.

   LCD에 문이 열림이 표시되고, 부저가 울리고, 팬이 회전한다.

3. 도어 스위치 또는 Bluetooth 어플의 도어 버튼 또는 웹의 도어 버튼을 누르면  LCD에 "Closing doors"라고 표시되며, 문이 닫히고, 문이 닫히면 LCD에 "Doors closed"라고 표시된다. 부저가 울린다.

4. 도어 스위치 또는 Bluetooth 어플의 도어 버튼 또는 웹의 도어 버튼을 누르면 LCD에 "Opening doors"라고 표시되며, 문이 열린다. 문이 열리면 LCD에 "Door opened"라고 표시되고, 부저가 울린다. 

5. 도어 스위치 또는 Bluetooth 어플의 도어 버튼 또는 웹의 도어 버튼을 누르면  LCD에 "Closing doors"라고 표시되며, 문이 닫히고, 팬이 꺼지고 LED가 꺼지고 부저가 울린다. LCD에 "Goodbye"라고 표시되고 2.5초 이후, LCD에 "SMART PARKING SYSTEM!"의 문구가 표시된다.

   

![](D:\스마트주차장 코드 순서도1.jpg)

![](D:\스마트주차장 코드 순서도2.jpg)



## 3. 코드 구성

### 	1. 전처리

​			*** 헤더파일 - 각종 필요한 라이브러리 포함**

```
#include <SoftwareSerial.h>   // software serial header file
#include <Servo.h>            // servo motor header file
#include <SPI.h>              // SPI header file
#include <MFRC522.h>          // RFID module header file
#include <LiquidCrystal_I2C.h>// LCD monitor header file
#include "Pitches.h"`         // buzzer frequency header file
```
​			*** 아두이노 핀 번호 정의 - 아두이노 핀 번호를 센서 및 디바이스 이름으로 정의**

```c
#define SERVO_PIN1 A0 // servo motor1 data pin 
#define SERVO_PIN2 A1 // servo motor2 data pin 
#define DC_MOTOR 6    // ventilator fan data pin
#define ECHO 2        // ultrasonic sensor Echo pin 
#define TRIG 3        // ultrasonic sensor Trigger pin
#define SW1 0         // LED on & off switch    
#define SW2 4         // ventilator fan on & off switch   
#define SW3 A2        // door open & close switch  
#define LED 5         // LED data pin   
#define BUZZER A3     // buzzer data pin
#define ARDUINO_TX 7  // Arduino Tx pin - Bluetooth Rx pin 
#define ARDUINO_RX 8  // Arduino Rx pin - Bluetooth Tx pin 
#define RST_PIN 9     // RF module RST pin
#define SS_PIN 10     // RF module SDA pin
```

​           *** 객체 및 변수 정의**

```c
SoftwareSerial bt(ARDUINO_RX,ARDUINO_TX);          // Arduino - Bluetooth module
LiquidCrystal_I2C lcd(0x27, 16, 2);                // LCD has 16 columns and 2 rows on screen

MFRC522 rfid(SS_PIN, RST_PIN);                     // RF module
const int rfid_pass[4] = {0x91, 0xE3, 0xCD, 0x1B}; // card ID: 91/E3/CD/1B -> Byte[0]/Byte[1]/Byte[2]/Byte[3]

Servo myservo1;                                    // servo motor1
Servo myservo2;                                    // servo motor2
const int open_angle[2] = { 13, 180 };             // angle[0] - > servo1 & angle[1] = servo2
const int close_angle[2] = { 110, 82 };            // the difference between the open and closed angles is 97 degree

float distanceCM; // distance between car and parking
int switch1_mode; // switch1 mode on or off
int switch2_mode; // switch2 mode of or off
int switch3_mode; // switch3 mode of or off
char msg_app;     // msg_app from arduino bluetooth app
char msg_web;     // msg_web from raspberrypi website

/*buzzer doorbell sound*/
const int melody[2][50] = { {NOTE_AS4, NOTE_F4, NOTE_C5, NOTE_D5, NOTE_F5}, // tone of sound 
                            {400, 200, 400, 400, 400} };                    // play time of sound 

/*status : LED, DOOR, FAN, PARKING, RFID_TAG*/
int led_status = 0; 
int door_status = 0;
int fan_status = 0;
int parking_status = 0;
int rfid_status = 0;
```



### 	2. void setup()

​			*** 아두이노 핀 초기화**

```c
Serial.begin(9600);         		// Serial Communication 
bt.begin(9600);             		// Bluetooth Communication

pinMode(TRIG, OUTPUT);      		// ultrasonic wave sensor Trigger pin
pinMode(ECHO, INPUT);       		// ultrasonic wave sensor Echo pin
  1
myservo1.attach(SERVO_PIN1);		// attach servo 1 variable to SERVO_PIN1
myservo2.attach(SERVO_PIN2);		// attach servo 2 variable to SERVO_PIN2 
myservo1.write(close_angle[0]);     // initializing servo motor 1
myservo2.write(close_angle[1]);     // initializing servo motor 2
  
pinMode(SW1, INPUT_PULLUP); 		// switch for LED On/Off
pinMode(SW2, INPUT_PULLUP); 		// switch for fan On/Off
pinMode(SW3, INPUT_PULLUP); 		// switch for door Op/Cs & LED On & FAN On
pinMode(LED, OUTPUT);       		// LED pin output
pinMode(BUZZER, OUTPUT);    		// BUZZER pin output
digitalWrite(LED, LOW);     		// initializing LED to off status 

/*RFID module*/
SPI.begin(); 
rfid.PCD_Init();

/*LCD*/
lcd.init();
lcd.backlight();
show_LCD( " SMART PARKING      SYSTEM!    " );
```



### 	3. void loop()

​			*** 주차장 초기 설정**

```c
void loop() 
{
	rf_module();                     // sensing if RFID is tagged
	distanceCM = measure_distance(); // sensing the distance between car and parking
	read_switchMode();               // reading values of "SW1" & "SW2" : 1 -> no pushing , 0 -> pushing
	msg_app = 'A';                   // initializing the "msg_app" from smartphone bluetooth app
	msg_web = 'W';                   // initializing the "msg_web" from raspberrypi server web
	read_bluetooth();                // reading "msg_app" from smartphone bluetooth app
	read_web();                      // reading "msg_web" from raspberrypi server web
```



​			* **주차장 문 열고 닫는 시나리오 - 문 열고, 주차 후 문 닫고, 나갈 때 문 열고, 다 나가면 문 닫는다.  / RFID TAG할 때만 가능**

```c
/***if you tag the owner RFID card, you can open the door***/
if (rfid_status == 1)
{
  /*When you're standing in front of the garage.*/
  if (door_status == 0 && parking_status == 0)
  {  
    if (switch3_mode == 0 || msg_app == 'D' || msg_web == 'D')  // push down the switch3 or the door on/off button of app or the door on/off button of web 
     {
        if (distanceCM > 10)
        {
          show_LCD( "Please get your car closer." );
          return;
        }
        
        /*distanceCM <= 10*/
        show_LCD( "Opening doors" );
        buzzer_sound(150);
        led_on();                   // turn on the LED when the door is opened
        move_servo("open");
        show_LCD( "Doors opened!" );
        buzzer_sound(500);
        analogWrite(DC_MOTOR, 90);  // turn on the fan when the door is opened

        led_status = 1;
        door_status = 1;
        parking_status = 1;
        fan_status = 1;
        
        print_status(); // print status (distance, led_status, door_status, parking_status, switch mode, rfid_status)
     }
  }
  /*Close the door when you finished parking a car.*/
  else if (door_status == 1 && parking_status == 1)
  {
    if (switch3_mode == 0 || msg_app == 'D' || msg_web == 'D')  // push down the switch3 or the door on/off button on app or the door on/off button on website
     {
        show_LCD( "Closing doors" );
        move_servo("close");
        show_LCD( "Doors closed!" );
        buzzer_sound(500);
        
        door_status = 0;
        
        print_status(); // print status (distance, led_status, door_status, parking_status, switch mode, rfid_status)
     }
  }
  /*Open the door before the car goes out.*/
  else if (door_status == 0 && parking_status == 1)
  {
    if (switch3_mode == 0 || msg_app == 'D' || msg_web == 'D')  // push down the switch3 or the door on/off button on app or the door on/off button on website
     {
        show_LCD( "Opening doors" );
        move_servo("open");
        show_LCD( "Doors opened!" );
        buzzer_sound(500);
        
        door_status = 1;
        parking_status = 0;

        print_status(); // print status (distance, led_status, door_status, parking_status, switch mode, rfid_status)
     }
  }
  /*Close the door when the car goes out.*/
  else if (door_status == 1 && parking_status == 0)
  {
    if (switch3_mode == 0 || msg_app == 'D' || msg_web == 'D')  // push down the switch3 or the door on/off button on app or the door on/off button on website
     {
        show_LCD( "Closing doors" );
        move_servo("close");
        analogWrite(DC_MOTOR, 0);  // turn off the fan when the door is closed
        led_off();                 // turn off the LED when the door is closed
        buzzer_sound(500);
        show_LCD( "    Goodbye    " ); 
        delay(2500); 
        show_LCD( " SMART PARKING      SYSTEM!    " );
        
        led_status = 0;
        door_status = 0;
        fan_status = 0;
        
        rfid_status = 0; // reset rfid_status
        print_status();  // print status (distance, led_status, door_status, parking_status, switch mode, rfid_status)
     }
  }
  /***finish the situation of parking and going outside***/

     rf_module(); // check if RFID is tagged
     delay(500);  // end of the process
```

​		

​			* **주차장 내부 LED 키고 끄는 내용 - 스위치, 블루투스 앱, 라즈베리파이 웹 버튼을 통해 가능  / RFID TAG할 때만 가능**

```c
  /*When you want to turn on/off the LED.*/   
  if ((switch1_mode == 0 || msg_app == 'L' || msg_web == 'L') && led_status == 0)
  { 
      show_LCD( "Light turned on" );
      led_on(); 
      led_status = 1;
      print_status(); // print status (distance, led_status, door_status, parking_status, switch mode, rfid_status
  }
  else if ((switch1_mode == 0 || msg_app == 'L' || msg_web == 'L') && led_status == 1)
  { 
      show_LCD( "Light turned off" );
      led_off(); 
      led_status = 0;
      print_status(); // print status (distance, led_status, door_status, parking_status, switch mode, rfid_status 
  }
```



​			* **주차장 내부 LED 키고 끄는 내용 - 스위치, 블루투스 앱, 라즈베리파이 웹사이트 버튼을 통해 가능  / RFID TAG할 때만 가능**

```c
  /*When you want to turn on/off the fan and adjust the wind power.*/
  if (switch2_mode == 0 || msg_app == 'F' || msg_web == 'F')
  {
        
    switch (fan_status)
    {
      case 0:
        show_LCD( "Wind Power:     WEAK" );
        analogWrite(DC_MOTOR, 90);   // average voltage delivered to DC motor = (90/255)*12V = 4.2V
        fan_status = 1;
        print_status();
        break;
        
      case 1:
        show_LCD( "Wind Power:     INTERMEDIATE" );
        analogWrite(DC_MOTOR, 100);   // average voltage delivered to DC motor = (100/255)*12V = 4.7V
        fan_status = 2;
        print_status();
        break;
        
      case 2:
        show_LCD( "Wind Power:     STRONG" );
        analogWrite(DC_MOTOR, 110);   // average voltage delivered to DC motor = (110/255)*12V = 5.2V
        fan_status = 3;
        print_status();
        break;
        
      case 3:
        show_LCD( "Fan turned off" );
        analogWrite(DC_MOTOR, 0);   
        fan_status = 0;
        print_status();
        break;    
    }
  }
  
    fflush(stdin);
    
} // rfid_status = 1
    

} // loop end
```



### 4. 정의한 함수 정리

```c
/*the function of sensing the distance between a car and a garage door*/
float measure_distance()
{
  digitalWrite(TRIG, LOW);
  delayMicroseconds(3);   // wait until TRIG pin is stabilized
  digitalWrite(TRIG, HIGH);
  delayMicroseconds(10);  // transmit pulse for 10us
  digitalWrite(TRIG, LOW);

  // read comeback time of the reflected sound
  unsigned long duration = pulseIn(ECHO, HIGH);  
  
  // (34000cm * (duration)sec)/2 -> distance between sersor and car
  float distance = ((340.0*100.0) * (duration/1000000.0))/2.0;  
  return distance;
}

/*the function of sensing switches on & off*/
void read_switchMode()
{
    switch1_mode = digitalRead(SW1);   // LED switch, switch1_mode = 0 -> on, 1 -> off
    switch2_mode = digitalRead(SW2);   // FAN switch, switch2_mode = 0 -> on, 1 -> off
    switch3_mode = digitalRead(SW3);   // door switch, switch3_mode = 0 -> closed, 1 -> open
}

/*the function of turning on the LED*/
void led_on()  
{
  if (led_status != 0)    // if led is already ON, return
    return;
  
  for (int i = 0; i <= 255; ++i)
  {
    analogWrite(LED, i);
    delay(3);
  }
}

/*the function of turning off the LED*/
void led_off()
{
  if (led_status == 0)    // if led is already OFF, return
    return;
  
  for (int i = 255; i >= 0; --i)
  {
    analogWrite(LED, i);
    delay(3);
  }  
}

/*the function of buzzer alarm*/
void buzzer_sound(int period)
{
    tone(BUZZER, NOTE_B5);
    delay(period);
    noTone(BUZZER);
}

/*the function of buzzer doorbell music*/
void buzzer_music() 
{
  for (int i = 0; ; i++)
  {
    tone(BUZZER, melody[0][i]);   
    delay(melody[1][i]);

    if (melody[0][i] == 0)    // stop the music 
    {
      noTone(BUZZER);
      break;
    }
  } 
}

/*the function of reading the value from bluetooth app*/
void read_bluetooth()
{
  if (bt.available())
  {
    msg_app = bt.read();  // value of ASCII CODE 
    delay(500);
  }
}

/*the function of reading the value from raspberrypi website*/
void read_web()
{
  if (Serial.available()>0)
  {
    msg_web = Serial.read(); // from raspberrypi
  }
}

/*the function of opening and closing the garage door by using servo motor*/
void move_servo(String mv)  
{
    if (mv == "open")
    {
      for (int angle = 0; angle <= 97; angle++)
      {
        myservo1.write(close_angle[0] - angle);  /* (closing) servo1: 110->13, servo2: 83->180 */        
        myservo2.write(close_angle[1] + angle);         
        delay(30);
      }
    }

    else if (mv == "close")
    {
      for (int angle = 0; angle <= 97; angle++)
      {
        myservo1.write(open_angle[0] + angle);   /* (opening) servo1: 13->110, servo2: 180->83 */ 
        myservo2.write(open_angle[1] - angle);   
        delay(30);
      }
    }
}

/*the function of tagging rfid card, only owner card can enable you to control parking area*/
void rf_module()
{  
    if (rfid.PICC_IsNewCardPresent()) 
    {
        
        if (rfid.PICC_ReadCardSerial())
        { 
            
            Serial.print(" RFID = ");
            printHex(rfid.uid.uidByte, rfid.uid.size);

            if (rfid.uid.uidByte[0] == rfid_pass[0] && rfid.uid.uidByte[1] == rfid_pass[1] && rfid.uid.uidByte[2] == rfid_pass[2] && rfid.uid.uidByte[3] == rfid_pass[3])
            {   // you will get access to the parking area if tagged card ID is the same as owner card ID  
               show_LCD( "Welcome to      We've PAVILION!" );
               
               if (rfid_status == 1)
               {
                  show_LCD( "You've already  tagged the card!" );    // if rfid_status == 1
                  delay(2000);                                      
                  show_LCD( "Welcome to      We've PAVILION!" );
               }
               else
               {
                  buzzer_music();   // if rfid_status == 0, buzzer makes a sound 
                  rfid_status = 1;
               }  
            }
            
            else // if the other ID card is tagged
            {
               if (rfid_status == 1)
               {
                  show_LCD( "You've already tagged the card!" );    // if rfid_status == 1
                  delay(2000);
                  show_LCD( "Welcome to      We've PAVILION!" );
               }
               else
               {
                  show_LCD( "Please use the  correct ID card." );
                  delay(2000); 
                  show_LCD( " SMART PARKING      SYSTEM!    " );
                  rfid_status = 0;
               } 
            }

            rfid.PICC_HaltA();        // halt PICC
            rfid.PCD_StopCrypto1();   // stop encryption on PCD
        }
    }   
}

/*print RFID ID number*/
void printHex(byte *buffer, byte bufferSize) 
{
  for (byte i = 0; i < bufferSize; i++) 
  {
      Serial.print(buffer[i] < 0x10 ? " 0" : " ");
      Serial.print(buffer[i], HEX);
  }
  Serial.println();
}

/*print the text on the LCD*/
void show_LCD(String text) 
{
  lcd.clear();
  lcd.setCursor(0,0);
  
  for (int i = 0; i < text.length(); ++i)
  {
    if (i < 16) 
    {
      lcd.setCursor(i,0);
      lcd.print(text[i]);           
    }
    else  // new line if there are more than 16 letters
    {
      lcd.setCursor(i - 16,1);
      lcd.print(text[i]);     
    }
  }

}

/*the function of printing the status of parking area on the arduino serial monitor*/
void print_status()
{  
  Serial.print("switch1_mode / switch2_mode / switch3_mode : ");
  Serial.print(switch1_mode);
  Serial.print(" / ");
  Serial.print(switch2_mode);
  Serial.print(" / ");
  Serial.println(switch3_mode);
  Serial.print("distance : ");
  Serial.println(distanceCM);
  Serial.print("led_status / fan_status / door_status / parking_status : ");
  Serial.print(led_status);
  Serial.print(" / ");
  Serial.print(fan_status);
  Serial.print(" / ");
  Serial.print(door_status);
  Serial.print(" / ");
  Serial.println(parking_status);
  Serial.print("rfid_status : "); 
  Serial.println(rfid_status); 
}
```



## 4. 코드 실행 사진

## 5. 작품 회로도

![](D:\스마트주차장 회로도 (Breadboard).jpg.jpg)



