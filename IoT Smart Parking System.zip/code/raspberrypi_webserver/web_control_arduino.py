from flask import Flask, request, render_template
import serial
import time

app = Flask(__name__)

ser = serial.Serial('/dev/ttyACM0',9600, timeout=1)
ser.flush()

@app.route('/')
def home():
    return render_template("index.html")

@app.route('/data', methods = ['POST'])
def data():

            data = request.form['control']

            if(data == 'led_on&off'): # LED ON/OFF code
                    ser.write(b"L") # Write "L" to arduino     
                    return home()

            elif(data == 'fan_on&off'): # FAN OF/OFF code
                    ser.write(b"F") # Write "F" to arduino
                    return home()

            elif(data == 'door_open&close'): # DOOR OPEN/CLOSE code
                    ser.write(b"D") # Write "D" to arduino
                    return home()
        
if __name__ == '__main__':
    app.run(host = '192.168.0.31', port = '80')
